const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'virtual_cfo'
});

async function main() {
  try {
    const { rows } = await pool.query("SELECT report_type, length(raw_data::text) FROM reports WHERE report_type LIKE '%StatementOfCashFlows%'");
    console.log("Cached StatementOfCashFlows reports:", rows);

    const fullRow = await pool.query("SELECT raw_data FROM reports WHERE report_type LIKE '%StatementOfCashFlows%' LIMIT 1");
    if (fullRow.rows[0]) {
      console.log("Full Report Data:", JSON.stringify(fullRow.rows[0].raw_data, null, 2));
    } else {
      console.log("No report found in DB.");
    }
  } catch (err) {
    console.error("Error executing query:", err);
  } finally {
    await pool.end();
  }
}

main();
