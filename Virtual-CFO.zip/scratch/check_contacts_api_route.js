const fs = require('fs');

console.log('/api/dashboard/reports/contacts/route.ts exists:', fs.existsSync('d:\\Virtual-CFO\\src\\app\\api\\dashboard\\reports\\contacts\\route.ts'));
console.log('/api/dashboard/contacts/route.ts exists:', fs.existsSync('d:\\Virtual-CFO\\src\\app\\api\\dashboard\\contacts\\route.ts'));
