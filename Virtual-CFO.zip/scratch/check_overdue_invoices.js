const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const query = `
    SELECT 
      invoice_number, 
      contact_name, 
      date, 
      due_date, 
      total, 
      amount_due, 
      amount_paid, 
      status, 
      type, 
      currency_code
    FROM invoices
    WHERE type = 'ACCREC' AND status IN ('AUTHORISED', 'SUBMITTED') AND amount_due > 0
    ORDER BY due_date ASC
    LIMIT 20
  `;
  const res = await pool.query(query);
  console.log('Total overdue invoices in DB sample:', res.rows.length);
  if (res.rows.length > 0) {
    console.log('Sample overdue invoice:', res.rows[0]);
  }
}

main().then(() => pool.end());
