const fs = require('fs');

const transcriptPath = 'C:\\Users\\Hp\\.gemini\\antigravity-ide\\brain\\5c9e4dc7-2c97-4dc2-9268-35a369526440\\.system_generated\\logs\\transcript_full.jsonl';

const lines = fs.readFileSync(transcriptPath, 'utf8').split('\n');

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  if (line.includes('profit-and-loss/page.tsx') && line.includes('CodeContent')) {
    try {
      const obj = JSON.parse(line);
      const toolCalls = obj.tool_calls || [];
      for (const tc of toolCalls) {
        if (tc.args && tc.args.TargetFile && tc.args.TargetFile.includes('profit-and-loss\\page.tsx')) {
          console.log('Found write_to_file at step', obj.step_index);
          fs.writeFileSync('d:\\Virtual-CFO\\scratch\\original_pl_page.tsx', tc.args.CodeContent);
          console.log('Saved to scratch/original_pl_page.tsx');
          process.exit(0);
        }
      }
    } catch (e) {}
  }
}

console.log('Not found in write_to_file');
