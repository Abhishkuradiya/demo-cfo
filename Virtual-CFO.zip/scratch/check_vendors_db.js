const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const topVendorsQuery = `
    SELECT 
      contact_name, 
      COUNT(*) as invoice_count,
      SUM(total) as total_spent,
      SUM(amount_due) as total_outstanding
    FROM invoices
    WHERE type = 'ACCPAY'
    GROUP BY contact_name
    ORDER BY total_spent DESC
    LIMIT 10
  `;
  const topVendors = await pool.query(topVendorsQuery);
  console.log('Top Vendors from PostgreSQL invoices (ACCPAY):', topVendors.rows);
}

main().then(() => pool.end());
