const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'virtual_cfo'
});

// Import or recreate the resolveAll logic
// Let's query payments, bank transactions, prepayments, overpayments
async function main() {
  try {
    const tenantId = 1;
    
    // Fetch payments
    const paymentsRes = await pool.query('SELECT * FROM payments WHERE tenant_id = $1', [tenantId]);
    const payments = paymentsRes.rows.map(r => ({
      ...r,
      PaymentID: r.external_id,
      Amount: parseFloat(r.amount || 0),
      PaymentType: r.payment_type,
      Status: r.status,
      Date: r.payment_date || r.created_at
    }));

    // Fetch bank transactions
    const bankTxnsRes = await pool.query("SELECT raw_data FROM reports WHERE report_type = 'BankTransactions' AND tenant_id = $1", [tenantId]);
    const bankTxns = bankTxnsRes.rows[0] ? bankTxnsRes.rows[0].raw_data : [];

    // Fetch prepayments
    const prepaymentsRes = await pool.query("SELECT raw_data FROM reports WHERE report_type = 'Prepayments' AND tenant_id = $1", [tenantId]);
    const prepayments = prepaymentsRes.rows[0] ? prepaymentsRes.rows[0].raw_data : [];

    // Fetch overpayments
    const overpaymentsRes = await pool.query("SELECT raw_data FROM reports WHERE report_type = 'Overpayments' AND tenant_id = $1", [tenantId]);
    const overpayments = overpaymentsRes.rows[0] ? overpaymentsRes.rows[0].raw_data : [];

    // Simple deduplication and verification resolver similar to FinancialEventResolver
    const events = [];
    const processedCompositeKeys = new Set();
    const processedPaymentIDs = new Set();
    const processedBankTxnIDs = new Set();

    const parseDate = (val) => {
      if (!val) return null;
      if (val instanceof Date) return val;
      if (typeof val === 'string') {
        const match = val.match(/\/Date\((\d+)/);
        if (match) return new Date(parseInt(match[1]));
        const d = new Date(val);
        return isNaN(d.getTime()) ? null : d;
      }
      return null;
    };

    // 1. Process payments
    for (const p of payments) {
      if (p.Status === 'DELETED') continue;
      const date = parseDate(p.Date);
      if (!date) continue;

      processedPaymentIDs.add(p.PaymentID);
      const key = `${date.toISOString().split('T')[0]}_${p.Amount.toFixed(2)}_${(p.payment_type || '').toLowerCase()}`;
      processedCompositeKeys.add(key);

      const direction = p.payment_type === 'ACCRECPAYMENT' ? 'IN' : 'OUT';
      events.push({
        id: p.PaymentID,
        source: 'Payment',
        direction,
        amount: p.Amount,
        date,
        contact: p.payment_type === 'ACCRECPAYMENT' ? 'Customer Payment' : 'Supplier Payment',
        reference: p.payment_type
      });
    }

    // 2. Process bank transactions
    for (const bt of bankTxns) {
      if (bt.Status === 'DELETED') continue;
      const date = parseDate(bt.Date);
      if (!date) continue;

      if (processedBankTxnIDs.has(bt.BankTransactionID)) continue;
      processedBankTxnIDs.add(bt.BankTransactionID);

      const key = `${date.toISOString().split('T')[0]}_${bt.Total.toFixed(2)}_${(bt.Contact?.Name || '').toLowerCase().trim()}`;
      if (processedCompositeKeys.has(key)) continue;
      processedCompositeKeys.add(key);

      const direction = bt.Type === 'RECEIVE' ? 'IN' : 'OUT';
      events.push({
        id: bt.BankTransactionID,
        source: 'BankTransaction',
        direction,
        amount: bt.Total,
        date,
        contact: bt.Contact?.Name || 'Unknown',
        reference: bt.Reference || ''
      });
    }

    const start = new Date('2026-03-01');
    const end = new Date('2026-08-24T23:59:59');

    // Filter by date range
    const filteredEvents = events.filter(e => e.date >= start && e.date <= end);
    console.log("TOTAL FILTERED EVENTS:", filteredEvents.length);

    // Let's classify each event
    let operatingIn = 0;
    let operatingOut = 0;
    let investingIn = 0;
    let investingOut = 0;
    let financingIn = 0;
    let financingOut = 0;

    for (const e of filteredEvents) {
      const contactLower = (e.contact || '').toLowerCase();
      const refLower = (e.reference || '').toLowerCase();
      
      // Let's build a classification logic
      let category = 'operating'; // Default to operating

      if (contactLower.includes('pc complete') || contactLower.includes('abc furniture') || contactLower.includes('laptop') || contactLower.includes('furniture') || contactLower.includes('office equipment')) {
        category = 'investing';
      } else if (contactLower.includes('bank west') || contactLower.includes('gateway motors') || contactLower.includes('loan') || contactLower.includes('financing')) {
        category = 'financing';
      }

      if (category === 'operating') {
        if (e.direction === 'IN') operatingIn += e.amount;
        else operatingOut += e.amount;
      } else if (category === 'investing') {
        if (e.direction === 'IN') investingIn += e.amount;
        else investingOut += e.amount;
      } else {
        if (e.direction === 'IN') financingIn += e.amount;
        else financingOut += e.amount;
      }

      console.log(`Event: ${e.date.toISOString().slice(0, 10)} | ${e.contact} | ${e.direction} | $${e.amount} | Cat: ${category}`);
    }

    console.log("\n--- SUMMARY OF CLASSIFIED ACTUALS ---");
    console.log(`Operating Cash Flow: IN=$${operatingIn.toFixed(2)}, OUT=$${operatingOut.toFixed(2)}, NET=$${(operatingIn - operatingOut).toFixed(2)}`);
    console.log(`Investing Cash Flow: IN=$${investingIn.toFixed(2)}, OUT=$${investingOut.toFixed(2)}, NET=$${(investingIn - investingOut).toFixed(2)}`);
    console.log(`Financing Cash Flow: IN=$${financingIn.toFixed(2)}, OUT=$${financingOut.toFixed(2)}, NET=$${(financingIn - financingOut).toFixed(2)}`);
    console.log(`Total Net: $${(operatingIn - operatingOut + investingIn - investingOut + financingIn - financingOut).toFixed(2)}`);

  } catch (err) {
    console.error("Error executing query:", err);
  } finally {
    await pool.end();
  }
}

main();
