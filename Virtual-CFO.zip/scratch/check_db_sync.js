const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'virtual_cfo'
});

async function main() {
  const tables = [
    'amazon_orders',
    'amazon_order_items',
    'amazon_products',
    'amazon_settlements',
    'amazon_inventory',
    'amazon_sales_metrics',
    'amazon_financial_events',
    'amazon_waterfall_summary',
    'tenant_credentials'
  ];

  console.log('=== DB INSPECTION FOR TENANT 3 (user: finance) ===\n');

  for (const t of tables) {
    try {
      const countRes = await pool.query(`SELECT COUNT(*) FROM ${t} WHERE tenant_id = 3`);
      const sampleRes = await pool.query(`SELECT * FROM ${t} WHERE tenant_id = 3 ORDER BY 1 DESC LIMIT 1`);
      console.log(`TABLE: ${t} -> Total Rows: ${countRes.rows[0].count}`);
      if (sampleRes.rows.length > 0) {
        const row = sampleRes.rows[0];
        console.log(' Sample record summary:');
        if (t === 'amazon_orders') {
          console.log(`   Order ID: ${row.amazon_order_id}, Status: ${row.order_status}, Total: £${row.order_total_amount}, Fees: £${row.amazon_fees}`);
        } else if (t === 'amazon_order_items') {
          console.log(`   ASIN: ${row.asin}, Title: ${row.title?.substring(0, 40)}, Price: £${row.item_price}, Image: ${row.image_url ? 'YES' : 'NO'}`);
        } else if (t === 'amazon_products') {
          console.log(`   ASIN: ${row.asin}, SKU: ${row.sku}, Title: ${row.title?.substring(0, 40)}, Image: ${row.image_url ? 'YES' : 'NO'}`);
        } else if (t === 'amazon_settlements') {
          console.log(`   Settlement ID: ${row.settlement_id}, Deposit: £${row.total_amount}`);
        } else if (t === 'tenant_credentials') {
          console.log(`   Provider: ${row.provider}, Region: ${row.tenant_identifier}`);
        } else {
          console.log(`   Fields: ${Object.keys(row).slice(0, 6).join(', ')}`);
        }
      } else {
        console.log('   (No rows)');
      }
      console.log('--------------------------------------------------');
    } catch (e) {
      console.log(`TABLE: ${t} -> Error: ${e.message}`);
    }
  }

  // Also check if any orders were synced across all tenants
  const totalOrders = await pool.query(`SELECT COUNT(*) FROM amazon_orders`);
  console.log(`TOTAL ORDERS ACROSS ALL TENANTS: ${totalOrders.rows[0].count}`);

  await pool.end();
}

main();
