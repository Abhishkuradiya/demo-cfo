const fs = require('fs');

console.log('/contacts exists:', fs.existsSync('d:\\Virtual-CFO\\src\\app\\(dashboard)\\contacts\\page.tsx'));
