const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const tables = await pool.query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
  console.log('PostgreSQL tables:', tables.rows.map(r => r.table_name));

  const reports = await pool.query("SELECT report_type, COUNT(*) FROM reports GROUP BY report_type");
  console.log('Cached report types:', reports.rows);

  const trackingReport = await pool.query("SELECT * FROM reports WHERE report_type = 'TrackingCategories' LIMIT 1");
  if (trackingReport.rows.length > 0) {
    console.log('TrackingCategories raw data sample:', trackingReport.rows[0].raw_data);
  } else {
    console.log('No TrackingCategories report cached yet in reports table.');
  }
}

main().then(() => pool.end());
