const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const tables = await pool.query("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'");
  console.log('Tables in DB:', tables.rows.map(t => t.table_name));

  try {
    const bankAccs = await pool.query("SELECT * FROM bank_accounts LIMIT 10");
    console.log('Bank accounts table sample:', bankAccs.rows);
  } catch (e) {
    console.log('No bank_accounts table, checking accounts table...');
    try {
      const accs = await pool.query("SELECT * FROM accounts WHERE type = 'BANK' OR type = 'BANK_ACCOUNT' OR name ILIKE '%bank%' OR name ILIKE '%paypal%' LIMIT 10");
      console.log('Accounts sample:', accs.rows);
    } catch (e2) {
      console.log('Checking reports table for BankSummary...');
      const reports = await pool.query("SELECT report_type FROM reports");
      console.log('Report types:', reports.rows.map(r => r.report_type));
    }
  }
}

main().then(() => pool.end());
