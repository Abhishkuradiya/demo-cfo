const fs = require('fs');

console.log('/customers exists:', fs.existsSync('d:\\Virtual-CFO\\src\\app\\(dashboard)\\customers\\page.tsx'));
console.log('/reports/customers exists:', fs.existsSync('d:\\Virtual-CFO\\src\\app\\(dashboard)\\reports\\customers\\page.tsx'));
