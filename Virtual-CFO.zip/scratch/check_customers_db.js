const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const contacts = await pool.query("SELECT * FROM contacts LIMIT 10");
  console.log('Contacts sample:', contacts.rows);

  const topCustomersQuery = `
    SELECT 
      contact_name, 
      COUNT(*) as invoice_count,
      SUM(total) as total_revenue,
      SUM(amount_due) as total_outstanding
    FROM invoices
    WHERE type = 'ACCREC'
    GROUP BY contact_name
    ORDER BY total_revenue DESC
    LIMIT 10
  `;
  const topCust = await pool.query(topCustomersQuery);
  console.log('Top Customers from PostgreSQL invoices:', topCust.rows);
}

main().then(() => pool.end());
