const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const reports = await pool.query("SELECT * FROM reports WHERE report_type ILIKE '%bank%' OR report_type ILIKE '%account%'");
  console.log('Bank reports found:', reports.rows.map(r => ({ type: r.report_type, id: r.id })));
  if (reports.rows.length > 0) {
    console.log('Sample report raw_data:', JSON.stringify(reports.rows[0].raw_data).slice(0, 300));
  }
}

main().then(() => pool.end());
