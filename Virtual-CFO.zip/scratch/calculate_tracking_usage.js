const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const trackingReport = await pool.query("SELECT * FROM reports WHERE report_type = 'TrackingCategories' LIMIT 1");
  const rawData = trackingReport.rows[0]?.raw_data || [];
  
  console.log('Categories count:', rawData.length);
  
  // Also check invoices for tracking option usage
  const invsRes = await pool.query("SELECT * FROM invoices");
  console.log('Total invoices in DB:', invsRes.rows.length);

  // Check sample invoice raw data for tracking categories
  const sampleInvWithTracking = invsRes.rows.find(i => i.raw_data && JSON.stringify(i.raw_data).includes('Tracking'));
  if (sampleInvWithTracking) {
    console.log('Sample invoice line items with tracking:', sampleInvWithTracking.raw_data.LineItems);
  } else {
    console.log('No invoice explicitly mentions line item tracking in sample.');
  }
}

main().then(() => pool.end());
