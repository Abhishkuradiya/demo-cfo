const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const res = await pool.query("SELECT * FROM invoices WHERE type = 'ACCREC'");
  const start = new Date('2026-08-01');
  const end = new Date('2026-08-31T23:59:59.999Z');

  const augSales = res.rows.filter(i => {
    const d = new Date(i.invoice_date);
    return d >= start && d <= end;
  });

  console.log(`=== AUG 2026 SALES INVOICES LIST (${augSales.length} TOTAL) ===`);
  augSales.forEach((i, idx) => {
    console.log(`${idx + 1}. [${i.invoice_number}] Contact: ${i.contact_name} | Status: ${i.status} | Date: ${new Date(i.invoice_date).toISOString().slice(0,10)} | Amount: £${i.total}`);
  });
}

main().then(() => pool.end());
