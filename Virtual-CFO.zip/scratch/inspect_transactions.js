const { Pool } = require('pg');

const pool = new Pool({
  host: process.env.DB_HOST || 'localhost',
  port: parseInt(process.env.DB_PORT || '5432'),
  user: process.env.DB_USER || 'postgres',
  password: process.env.DB_PASSWORD || 'postgres',
  database: process.env.DB_NAME || 'virtual_cfo'
});

async function main() {
  try {
    const bankTxnsRes = await pool.query("SELECT raw_data FROM reports WHERE report_type = 'BankTransactions' AND tenant_id = 1");
    if (bankTxnsRes.rows[0]) {
      const list = bankTxnsRes.rows[0].raw_data;
      console.log("BANK TXNS COUNT:", list.length);
      console.log("BANK TXN SAMPLE ROW:", JSON.stringify(list[0], null, 2));
    } else {
      console.log("No BankTransactions found in DB.");
    }

    const prepaysRes = await pool.query("SELECT raw_data FROM reports WHERE report_type = 'Prepayments' AND tenant_id = 1");
    if (prepaysRes.rows[0]) {
      const list = prepaysRes.rows[0].raw_data;
      console.log("PREPAYMENTS SAMPLE:", JSON.stringify(list[0], null, 2));
    }

    const overpaysRes = await pool.query("SELECT raw_data FROM reports WHERE report_type = 'Overpayments' AND tenant_id = 1");
    if (overpaysRes.rows[0]) {
      const list = overpaysRes.rows[0].raw_data;
      console.log("OVERPAYMENTS SAMPLE:", JSON.stringify(list[0], null, 2));
    }
  } catch (err) {
    console.error("Error executing query:", err);
  } finally {
    await pool.end();
  }
}

main();
