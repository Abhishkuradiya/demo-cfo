const { Pool } = require('pg');
const pool = new Pool({ host: 'localhost', port: 5432, user: 'postgres', password: 'postgres', database: 'virtual_cfo' });

async function main() {
  const res = await pool.query("SELECT * FROM invoices WHERE type = 'ACCPAY'");
  console.log('Total PG Vendor Bills (ACCPAY):', res.rows.length);

  const start = new Date('2026-08-01');
  const end = new Date('2026-08-31T23:59:59.999Z');

  const augBills = res.rows.filter(i => {
    const d = new Date(i.invoice_date);
    return d >= start && d <= end;
  });

  console.log('Aug 2026 Vendor Bills count:', augBills.length);
  console.log('Sample Aug 2026 Vendor Bills:', augBills.slice(0, 5).map(i => ({
    num: i.invoice_number,
    vendor: i.contact_name,
    status: i.status,
    amount: i.total,
    amountDue: i.amount_due,
    date: i.invoice_date
  })));
}

main().then(() => pool.end());
