const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const cols = await pool.query("SELECT column_name FROM information_schema.columns WHERE table_name = 'invoices'");
  console.log('Invoices table columns:', cols.rows.map(c => c.column_name));

  const sample = await pool.query("SELECT * FROM invoices LIMIT 1");
  console.log('Sample invoice row:', sample.rows[0]);
}

main().then(() => pool.end());
