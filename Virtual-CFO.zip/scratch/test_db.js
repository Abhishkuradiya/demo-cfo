const { Pool } = require('pg');
const pool = new Pool({ host: 'localhost', port: 5432, user: 'postgres', password: 'postgres', database: 'virtual_cfo' });

async function main() {
  const res = await pool.query("SELECT * FROM invoices WHERE type = 'ACCREC'");
  console.log('Total PG ACCREC Invoices:', res.rows.length);

  const start = new Date('2026-08-01');
  const end = new Date('2026-08-31T23:59:59.999Z');

  const augSales = res.rows.filter(i => {
    const d = new Date(i.invoice_date);
    return d >= start && d <= end;
  });

  console.log('Aug 2026 Sales Invoices count:', augSales.length);
  console.log('Sample Aug 2026 Sales Invoices:', augSales.slice(0, 5).map(i => ({
    num: i.invoice_number,
    contact: i.contact_name,
    status: i.status,
    amount: i.total,
    date: i.invoice_date
  })));
}

main().then(() => pool.end());
