const fs = require('fs');

try {
  fs.unlinkSync('d:\\Virtual-CFO\\scratch\\original_contacts_page.tsx');
  console.log('Deleted scratch file');
} catch (e) {
  console.log('File already deleted');
}
