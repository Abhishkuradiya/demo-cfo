const fs = require('fs');

const transcriptPath = 'C:\\Users\\Hp\\.gemini\\antigravity-ide\\brain\\5c9e4dc7-2c97-4dc2-9268-35a369526440\\.system_generated\\logs\\transcript_full.jsonl';

const lines = fs.readFileSync(transcriptPath, 'utf8').split('\n');

for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  if (line.includes('ContactsPage') && line.includes('export default function ContactsPage')) {
    try {
      const obj = JSON.parse(line);
      console.log('Found ContactsPage at step', obj.step_index);
      const content = obj.content || '';
      if (content.includes('export default function ContactsPage')) {
        const codeStart = content.indexOf('\'use client\'');
        if (codeStart !== -1) {
          const code = content.slice(codeStart);
          fs.writeFileSync('d:\\Virtual-CFO\\scratch\\original_contacts_page.tsx', code);
          console.log('Saved to scratch/original_contacts_page.tsx');
          process.exit(0);
        }
      }
    } catch (e) {}
  }
}

console.log('Done searching transcript');
