const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const query = `
    SELECT 
      invoice_number, 
      contact_name, 
      invoice_date, 
      due_date, 
      total, 
      amount_due, 
      amount_paid, 
      status, 
      type, 
      currency,
      (CURRENT_DATE - due_date::date) as overdue_days
    FROM invoices
    WHERE type = 'ACCREC' 
      AND status IN ('AUTHORISED', 'SUBMITTED') 
      AND amount_due > 0
    ORDER BY (CURRENT_DATE - due_date::date) DESC
    LIMIT 20
  `;
  const res = await pool.query(query);
  console.log('Total overdue invoices found in PostgreSQL:', res.rows.length);
  if (res.rows.length > 0) {
    console.log('Top 5 overdue invoices:');
    res.rows.slice(0, 5).forEach((r, i) => {
      console.log(`${i+1}. ${r.invoice_number} | ${r.contact_name} | Due: ${r.due_date.toISOString().slice(0,10)} | Amount Due: £${r.amount_due} | Overdue: ${r.overdue_days} days`);
    });
  }
}

main().then(() => pool.end());
