const fs = require('fs');
const readline = require('readline');

const transcriptPath = 'C:\\Users\\Hp\\.gemini\\antigravity-ide\\brain\\5c9e4dc7-2c97-4dc2-9268-35a369526440\\.system_generated\\logs\\transcript_full.jsonl';

const rl = readline.createInterface({
  input: fs.createReadStream(transcriptPath),
  crlfDelay: Infinity
});

let foundCount = 0;

rl.on('line', (line) => {
  if (line.includes('profit-and-loss/page.tsx') && line.includes('TargetContent') && !line.includes('viewMode')) {
    foundCount++;
    console.log(`--- Match ${foundCount} ---`);
    console.log(line.slice(0, 500));
  }
});
