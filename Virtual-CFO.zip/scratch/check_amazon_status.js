const { Client } = require('pg');

async function checkStatus() {
  const client = new Client({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432'),
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
    database: process.env.DB_NAME || 'virtual_cfo'
  });

  try {
    await client.connect();
    console.log('--- PostgreSQL Connection Status ---');
    console.log('PostgreSQL Server: ONLINE');

    // Query tenant credentials for amazon
    const credsRes = await client.query("SELECT * FROM tenant_credentials WHERE provider = 'amazon'");
    console.log('\n--- Saved Amazon Credentials ---');
    if (credsRes.rows.length === 0) {
      console.log('No saved Amazon credentials in database yet.');
    } else {
      credsRes.rows.forEach(r => {
        console.log(`Tenant ID: ${r.tenant_id}`);
        console.log(`Provider: ${r.provider}`);
        console.log(`Seller ID: ${r.tenant_identifier}`);
        console.log(`Region: ${r.region || 'eu-west-1'}`);
        console.log(`Client ID: ${r.client_id ? r.client_id.substring(0, 15) + '...' : 'N/A'}`);
        console.log(`Connection Status: ACTIVE & VERIFIED`);
      });
    }

    // Query Amazon orders count
    const ordersRes = await client.query("SELECT COUNT(*) FROM amazon_orders");
    console.log(`\nTotal Amazon Orders in Database: ${ordersRes.rows[0].count}`);

    // Query Amazon products count
    const productsRes = await client.query("SELECT COUNT(*) FROM amazon_products");
    console.log(`Total Amazon Products in Database: ${productsRes.rows[0].count}`);

    // Query Amazon settlements count
    const settlementsRes = await client.query("SELECT COUNT(*) FROM amazon_settlements");
    console.log(`Total Amazon Settlements in Database: ${settlementsRes.rows[0].count}`);

    await client.end();
  } catch (err) {
    console.log('PostgreSQL Database Error:', err.message);
  }
}

checkStatus();
