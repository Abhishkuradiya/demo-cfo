const { Pool } = require('pg');
const pool = new Pool({
  host: 'localhost',
  port: 5432,
  user: 'postgres',
  password: 'postgres',
  database: 'virtual_cfo'
});

async function main() {
  const trackingReport = await pool.query("SELECT * FROM reports WHERE report_type = 'TrackingCategories' LIMIT 1");
  if (trackingReport.rows.length > 0) {
    console.log('TrackingCategories full JSON:', JSON.stringify(trackingReport.rows[0].raw_data, null, 2));
  }
}

main().then(() => pool.end());
