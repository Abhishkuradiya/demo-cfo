const { Pool } = require('pg');
const fs = require('fs');
const path = require('path');

const connectionString = process.env.DATABASE_URL || 'postgresql://postgres:postgres@localhost:5432/virtual_cfo';
const pool = new Pool({ connectionString });

async function fixPnlInDb() {
  console.log('Inspecting and updating stored ProfitAndLoss reports in Database...');

  const realPnlRawData = {
    ReportID: "ProfitAndLoss",
    ReportName: "Profit and Loss",
    ReportType: "ProfitAndLoss",
    ReportTitles: [
      "Profit and Loss",
      "MI Health Ltd",
      "For the 6 months ended 31 August 2026"
    ],
    Rows: [
      {
        RowType: "Section",
        Title: "Turnover",
        Rows: [
          { RowType: "Row", Cells: [{ Value: "Website Sales" }, { Value: "1879493.38" }] },
          { RowType: "Row", Cells: [{ Value: "Amazon Sales" }, { Value: "1757169.61" }] },
          { RowType: "Row", Cells: [{ Value: "Ebay sales" }, { Value: "500618.21" }] },
          { RowType: "Row", Cells: [{ Value: "Sales" }, { Value: "262340.81" }] },
          { RowType: "Row", Cells: [{ Value: "Inter company sales" }, { Value: "75542.76" }] },
          { RowType: "Row", Cells: [{ Value: "Groupon Sales" }, { Value: "48562.56" }] },
          { RowType: "Row", Cells: [{ Value: "SLA & Contract Income" }, { Value: "8550.00" }] }
        ],
        Summary: {
          RowType: "SummaryRow",
          Cells: [{ Value: "Total Turnover" }, { Value: "4532277.33" }]
        }
      },
      {
        RowType: "Section",
        Title: "Cost of Sales",
        Rows: [
          { RowType: "Row", Cells: [{ Value: "3PL" }, { Value: "5250.46" }] },
          { RowType: "Row", Cells: [{ Value: "Amazon Fee" }, { Value: "293363.86" }] },
          { RowType: "Row", Cells: [{ Value: "Amazon Shipping" }, { Value: "124594.16" }] },
          { RowType: "Row", Cells: [{ Value: "Closing stock" }, { Value: "-150000.00" }] },
          { RowType: "Row", Cells: [{ Value: "Cost of goods or services" }, { Value: "712350.86" }] },
          { RowType: "Row", Cells: [{ Value: "Courier & Shipping Costs" }, { Value: "244208.87" }] },
          { RowType: "Row", Cells: [{ Value: "Ebay fee" }, { Value: "95469.02" }] },
          { RowType: "Row", Cells: [{ Value: "Inter company Purchases" }, { Value: "2323680.55" }] },
          { RowType: "Row", Cells: [{ Value: "Logistics" }, { Value: "350.00" }] },
          { RowType: "Row", Cells: [{ Value: "Merchant Fees" }, { Value: "33505.19" }] },
          { RowType: "Row", Cells: [{ Value: "Opening stock" }, { Value: "108046.68" }] },
          { RowType: "Row", Cells: [{ Value: "Packaging Materials" }, { Value: "15265.35" }] },
          { RowType: "Row", Cells: [{ Value: "Referral Fees" }, { Value: "33367.86" }] }
        ],
        Summary: {
          RowType: "SummaryRow",
          Cells: [{ Value: "Total Cost of Sales" }, { Value: "3839452.86" }]
        }
      },
      {
        RowType: "Section",
        Title: "Gross Profit",
        Summary: {
          RowType: "SummaryRow",
          Cells: [{ Value: "Gross Profit" }, { Value: "692824.47" }]
        }
      }
    ]
  };

  try {
    // 1. Update PostgreSQL DB if connected
    const res = await pool.query(
      "UPDATE reports SET raw_data = $1 WHERE report_type LIKE 'ProfitAndLoss%'",
      [JSON.stringify(realPnlRawData)]
    );
    console.log(`Updated PostgreSQL reports table rows: ${res.rowCount}`);
  } catch (err) {
    console.error('PostgreSQL update error (or not running):', err.message);
  }

  // 2. Update JSON DB fallback if present
  try {
    const jsonPath = path.join(__dirname, '../data/db.json');
    if (fs.existsSync(jsonPath)) {
      const dbContent = JSON.parse(fs.readFileSync(jsonPath, 'utf8'));
      if (dbContent.reports && Array.isArray(dbContent.reports)) {
        let count = 0;
        dbContent.reports.forEach((r) => {
          if (r.report_type && r.report_type.startsWith('ProfitAndLoss')) {
            r.raw_data = realPnlRawData;
            count++;
          }
        });
        fs.writeFileSync(jsonPath, JSON.stringify(dbContent, null, 2));
        console.log(`Updated JSON DB reports: ${count}`);
      }
    }
  } catch (err) {
    console.error('JSON DB update error:', err.message);
  }

  await pool.end();
  console.log('Finished updating P&L database records.');
}

fixPnlInDb();
